package br.com.fis.utl;

import java.util.Scanner;

public class Teclado {
	private static final String 
	    MSG_NUMBER_INVALID="Erro: o valor informado n�o � um nro v�lido!";
	private static Scanner scan = 
			new Scanner(System.in);
	
	public static String lerString()
	{
		return scan.nextLine();
	}
	public static int lerInt()
	{
		try {
			return Integer.parseInt(lerString());			
		} catch (Exception e) {
			throw new RuntimeException(MSG_NUMBER_INVALID);
		}
	}
	public static long lerLong()
	{
		try {
			return Long.parseLong(lerString());	
		} catch (Exception e) {
			throw new RuntimeException(MSG_NUMBER_INVALID);
		}
		
	}
}
