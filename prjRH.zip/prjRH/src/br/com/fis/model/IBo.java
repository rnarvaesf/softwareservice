package br.com.fis.model;

public interface IBo<T> {

	public void save(T obj) throws Exception;
	public String getAll() throws Exception;
	
}
