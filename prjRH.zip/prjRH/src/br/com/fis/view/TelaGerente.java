package br.com.fis.view;

import br.com.fis.model.Empregado;
import br.com.fis.model.EmpregadoBO;
import br.com.fis.model.Gerente;
import br.com.fis.utl.Teclado;

public class TelaGerente {

	private static Gerente ger;
	private static final String MSG_SAVE="Grava��o com sucesso";
	
	public static void solicitarDados() 
	{
		if (TelaDepartamento.getDepto()==null)
		{
			System.out.println("O depto n�o foi cadastrado");
			return;
		}
		
		ger= new Gerente();
		
		System.out.println("Informe o cpf: ");
		ger.setCpf(Teclado.lerLong());
		
		System.out.println("Informe o nome do funcion�rio: ");
		ger.setNome(Teclado.lerString());
		
		//guarda depto
		ger.setDepartamento(TelaDepartamento.getDepto());
		
	}
	public static void save(EmpregadoBO bo) 
	{
		try {
			if (TelaDepartamento.getDepto()==null)
			{
				return;
			}
		
			bo.save(ger);
			System.out.println(MSG_SAVE);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		}
		
	}

}
