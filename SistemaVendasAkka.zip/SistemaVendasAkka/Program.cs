﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Akka.Actor;
using SistemaVendasAkka.Actor;
using SistemaVendasAkka.Domain;
using SistemaVendasAkka.ValueObj;
namespace SistemaVendasAkka
{
    class Program
    {
        static void Main(string[] args)
        {
            var system = ActorSystem.Create("TransactionSystem");

            var saleActor = system.ActorOf<SaleActor>(nameof(SaleActor));

            var transA = new Transaction(TransactionType.ECommerce, 100.00, "0101");
            var transB = new Transaction(TransactionType.TEF, 101.00, "0202");
            var transC = new Transaction(TransactionType.POS, 80.00, "0103");

            saleActor.Tell(transA);
            saleActor.Tell(transB);
            saleActor.Tell(transC);

            Console.Read();
        }
    }
}
