﻿namespace SistemaVendasAkka.ValueObj
{
    public enum TransactionType
    {
        ECommerce = 0,
        TEF = 1,
        POS = 2
    }
}