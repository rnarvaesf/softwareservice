﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaVendasAkka.ValueObj;

namespace SistemaVendasAkka.Domain
{
    public class Transaction
    {
        public Guid Id { get; private set; }
        public DateTime CreateDate { get; private set; }
        public TransactionType TransactionType { get; private set; }
        public double Amount { get; private set; }
        public string SaleCode { get; private set; }

        public Transaction(TransactionType transactionType, double amount, string saleCode)
        {
            Id = Guid.NewGuid();
            CreateDate = DateTime.UtcNow;
            TransactionType = transactionType;
            Amount = amount;
            SaleCode = saleCode;
        }
    }
}
