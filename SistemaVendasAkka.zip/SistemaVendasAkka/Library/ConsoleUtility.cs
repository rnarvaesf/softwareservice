﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaVendasAkka.Library
{
    public static class ConsoleUtility
    {
        private static readonly object _sync = new object();
        
        public static void printMsg(string message, bool sucess = true)
        {
            var foreGroundColor = sucess ? ConsoleColor.Green : ConsoleColor.Red;

            lock (_sync)
            {
                Console.ForegroundColor = foreGroundColor;
                Console.WriteLine($"{DateTime.Now:o} => {message}");
            }
        }
    }
}
