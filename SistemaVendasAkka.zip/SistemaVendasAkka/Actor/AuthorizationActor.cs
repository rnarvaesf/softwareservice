﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Akka.Actor;
using SistemaVendasAkka.Domain;
using SistemaVendasAkka.Library;
using SistemaVendasAkka.ValueObj;


namespace SistemaVendasAkka.Actor
{
    public class AuthorizationActor : ReceiveActor
    {
        public AuthorizationActor()
        { 
            Receive<Transaction>(transaction =>
                {
                    if ((transaction.TransactionType == TransactionType.ECommerce &&
                        transaction.Amount < 100) ||
                        (transaction.TransactionType != TransactionType.ECommerce && transaction.Amount >= 10))
                        ConsoleUtility.printMsg("Autorizado código: 00 - sucesso");
                    else
                        ConsoleUtility.printMsg("Autorização código 50 - você não tem autorização para este tipo de transação",false);
                }
            );
        }

    }
}
