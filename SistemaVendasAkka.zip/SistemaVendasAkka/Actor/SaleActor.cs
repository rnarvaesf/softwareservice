﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Akka.Actor;
using SistemaVendasAkka.Domain;
using SistemaVendasAkka.Library;

namespace SistemaVendasAkka.Actor
{
    public class SaleActor : ReceiveActor
    {
        public SaleActor()
        {
            Receive<Transaction>(transaction => {
                if (transaction.SaleCode == "0101" || transaction.SaleCode == "0202")
                {
                    var authorizationActor = Context.ActorOf(Props.Create(() => new AuthorizationActor()));
                    authorizationActor.Tell(transaction);
                    authorizationActor.GracefulStop(new TimeSpan(10000));

                }
                else
                    ConsoleUtility.printMsg("Autorização código 77 - não autorizado, código da venda inválido",false);
            
            
            });
        }
    }
}
