package br.com.fis.model;

public class Departamento {
	private int numero;
	private String nome;

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	@Override
	public String toString() {
		
		return "Departamento "+this.getNome()+ " de c�digo "+
				this.getNumero();
	}
}
