package br.com.fis.view;

import br.com.fis.model.Empregado;
import br.com.fis.model.EmpregadoBO;
import br.com.fis.utl.Teclado;

public class TelaEmpregado {
	private static Empregado emp;
	private static final String MSG_SAVE="Grava��o com sucesso";
	
	public static void solicitarDados() 
	{
		emp= new Empregado();		
		System.out.println("Informe o cpf: ");
		emp.setCpf(Teclado.lerLong());
		
		System.out.println("Informe o nome do funcion�rio: ");
		emp.setNome(Teclado.lerString());
		
		
	}
	public static void save(EmpregadoBO bo) 
	{
		try {
			bo.save(emp);
			System.out.println(MSG_SAVE);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		}
		
	}

}
